Don't remove dummyyummy.zip and user_agents.txt
if you want to replace it with your own shell script, just put it in dummyyummy.zip and then rename the shell to wp-signup.php

Join : https://t.me/exploi7
Coded by : https://t.me/xxyz4

Best all in one list maker and exploiter tools : https://xreverselabs.my.id/